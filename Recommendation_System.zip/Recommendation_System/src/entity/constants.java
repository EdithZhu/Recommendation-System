package entity;

public class constants {
	public static String address = "address";
	public static String line1 = "line1";
}
